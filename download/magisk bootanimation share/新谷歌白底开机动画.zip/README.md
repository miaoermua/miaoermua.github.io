# Magisk 模块模板非官方中文版

[English Version](https://github.com/E7KMbb/magisk-module-installer)

**如果你想把模块上传到在线存储库,请修改 `README.md` !** 当用户点击 Magisk Manager 中的模块时，这个 "README.md" 将显示在 Webview 对话框中，所以请确保在这里放置一些信息/修改日志/注释。

有关如何使用此模块安装程序的更多信息，请参考 [官方文档](https://topjohnwu.github.io/Magisk/guides.html)

如果你不熟悉 Markdown 的语法，可以从GitHub的在线 Markdown 编辑器开始，它将允许你在发布之前进行预览。 如果你需要更多帮助, [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) 将非常方便.
